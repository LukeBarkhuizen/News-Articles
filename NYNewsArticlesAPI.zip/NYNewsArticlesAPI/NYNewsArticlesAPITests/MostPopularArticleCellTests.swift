//
//  MostPopularArticleCellTests.swift
//  NYNewsArticlesAPITests
//
//  Created by Luke Barkhuizen (ZA) on 2023/09/21.
//

import XCTest
@testable import NYNewsArticlesAPI

class MostPopularArticleCellTests: XCTestCase {
    
    var cell: MostPopularArticleCell!
    
    override func setUp() {
        super.setUp()
        cell = Bundle(for: MostPopularArticleCell.self).loadNibNamed("MostPopularArticleCell", owner: nil)?.first as? MostPopularArticleCell
        XCTAssertNotNil(cell)
    }
    
    override func tearDown() {
        cell = nil
        super.tearDown()
    }
    
    func testConfigureCellView() {
        // Create a sample article model for testing
        let articleModel = TopArticles(
            publishedDate: "2023-09-21",
            author: "Sample Author",
            articleTitle: "Sample Title"
        )
        cell.articleImage.image = UIImage(systemName: "photo")
        
        // Configure the cell with the sample article model
        cell.configureCellView(articleModel: articleModel)
        
        // Assert that the UI elements in the cell are set correctly
        XCTAssertEqual(cell.titleLabelView.text, "Sample Title")
        XCTAssertEqual(cell.authorLabelView.text, "Sample Author")
        XCTAssertEqual(cell.publishedDateLabelView.text, "Date published: 2023-09-21")
        XCTAssertNotNil(cell.articleImage.image)
    }
}
