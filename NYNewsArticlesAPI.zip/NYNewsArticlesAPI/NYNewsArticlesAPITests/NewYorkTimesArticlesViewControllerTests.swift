//
//  NewYorkTimesArticlesViewControllerTests.swift
//  NYNewsArticlesAPITests
//
//  Created by Luke Barkhuizen (ZA) on 2023/09/21.
//

import UIKit
import XCTest
@testable import NYNewsArticlesAPI

class NewYorkTimesArticlesViewControllerTests: XCTestCase {
    
    var viewController: NewYorkTimesArticlesViewController!
    
    override func setUp() {
        super.setUp()
        viewController = NewYorkTimesArticlesViewController()
    }
    
    override func tearDown() {
        viewController = nil
        super.tearDown()
    }
    
    func testTableViewSettings() {
        // Check if the tableView is registered with the expected cell identifier
        let cell = Bundle(for: MostPopularArticleCell.self).loadNibNamed("MostPopularArticleCell", owner: nil)?.first as? MostPopularArticleCell
        XCTAssertNotNil(cell)
    }
    
    func testViewModelInitialization() {
        // Test if the view controller's viewModel has been initialized correctly
        XCTAssertNotNil(viewController.viewModel)
        XCTAssertNotNil(viewController.viewModel.delegate)
    }
}
