//
//  NewYorkTimesArticlesViewModelTests.swift
//  NYNewsArticlesAPITests
//
//  Created by Luke Barkhuizen (ZA) on 2023/09/21.
//

import XCTest
@testable import NYNewsArticlesAPI

class NewYorkTimesArticlesViewModelTests: XCTestCase {
    
    class MockDelegate: NewYorkTimesArticlesViewModelDelegate {
        var configureArticleListCalled = false
        var articles: [TopArticles]?
        
        func configureArticleList(articles: [TopArticles]) {
            configureArticleListCalled = true
            self.articles = articles
        }
    }
    
    var viewModel: NewYorkTimesArticlesViewModel!
    var mockDelegate: MockDelegate!
    
    override func setUp() {
        super.setUp()
        mockDelegate = MockDelegate()
        viewModel = NewYorkTimesArticlesViewModel(delegate: mockDelegate)
    }
    
    override func tearDown() {
        viewModel = nil
        mockDelegate = nil
        super.tearDown()
    }
    
    func testViewModelInitialization() {
        XCTAssertNotNil(viewModel.delegate)
    }
    
    func testGetAllMostPopularArticlesSuccess() {
        let response = NewYorkTimesResponseModel(results: [TopArticles(articleTitle: "Title")])
        let apiCallerMock = APICallerMock()
        apiCallerMock.getMostPopularArticlesResult = .success(response)
        APICaller.shared = apiCallerMock
        viewModel.getAllMostPopularArticles()
        XCTAssertTrue(mockDelegate.configureArticleListCalled)
        XCTAssertEqual(mockDelegate.articles?.count, 1)
    }
    
    func testGetAllMostPopularArticlesFailure() {
        let apiCallerMock = APICallerMock()
        apiCallerMock.getMostPopularArticlesResult = .failure(MockError.someError)
        viewModel.getAllMostPopularArticles()
        XCTAssertFalse(mockDelegate.configureArticleListCalled)
        XCTAssertNil(mockDelegate.articles)
    }
}

// Mock for APICaller to simulate success and failure

class APICallerMock: APICaller {
    
    var getMostPopularArticlesResult: Result<NewYorkTimesResponseModel, Error>?
    
    override func getMostPopularArticles(completion: @escaping (Result<NewYorkTimesResponseModel, Error>) -> Void) {
        if let result = getMostPopularArticlesResult {
            completion(result)
        }
    }
}

// Mock error for testing

enum MockError: Error {
    
    case someError
}

