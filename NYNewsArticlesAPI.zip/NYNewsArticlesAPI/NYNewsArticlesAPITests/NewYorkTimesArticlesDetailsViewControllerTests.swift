//
//  NewYorkTimesArticlesDetailsViewControllerTests.swift
//  NYNewsArticlesAPITests
//
//  Created by Luke Barkhuizen (ZA) on 2023/09/22.
//

import XCTest
@testable import NYNewsArticlesAPI

class NewYorkTimesArticlesDetailsViewControllerTests: XCTestCase {
    
    var viewController: NewYorkTimesArticleDetailsViewController!
    
    override func setUp() {
        super.setUp()
        viewController = NewYorkTimesArticleDetailsViewController()
    }
    
    override func tearDown() {
        viewController = nil
        super.tearDown()
    }
    
    func testConfigureArticleDetails() {
        
        // Create a mock TopArticles model
        let articleModel = TopArticles(
            publishedDate: "2023-09-22",
            author: "Test Author",
            articleTitle: "Test Title",
            articleContent: "Test Content",
            articleSection: "Test Section")
        
        // Set the articleDetails property of the view controller
        viewController.articleDetails = articleModel
        XCTAssertEqual(viewController.articleDetails?.articleContent, articleModel.articleContent)
        XCTAssertEqual(viewController.articleDetails?.author, articleModel.author)
        XCTAssertEqual(viewController.articleDetails?.articleTitle, articleModel.articleTitle)
        XCTAssertEqual(viewController.articleDetails?.articleSection, articleModel.articleSection)
        XCTAssertEqual(viewController.articleDetails?.publishedDate, articleModel.publishedDate)
    }
}






