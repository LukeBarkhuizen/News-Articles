//
//  APICaller.swift
//  NYNewsArticlesAPI
//
//  Created by Luke Barkhuizen (ZA) on 2023/09/19.
//

import Foundation
import UIKit


struct NewYorkTimesResponseModel: Codable {
    
    var results: [TopArticles]?
}

struct TopArticles: Codable {
    
    var source: String?
    var publishedDate: String?
    var author: String?
    var articleTitle: String?
    var articleContent: String?
    var articleImage: [ArticleImage]?
    var articleSection: String?
    var articleKeywords: String?
    
    enum CodingKeys: String, CodingKey {
        
        case source
        case publishedDate = "published_date"
        case author = "byline"
        case articleTitle = "title"
        case articleContent = "abstract"
        case articleImage = "media"
        case articleSection = "section"
        case articleKeywords = "adx_keywords"
    }
}

struct ArticleImage: Codable {
    
    var image: [Image]?
    
    enum CodingKeys: String, CodingKey {
        
        case image = "media-metadata"
    }
}

struct Image: Codable {
    
    var imageURL: String?
    
    enum CodingKeys: String, CodingKey {
        
        case imageURL = "url"
    }
}

class APICaller {
    
    static var shared = APICaller()
    fileprivate let newYorkTimesURL = URL(string: "https://api.nytimes.com/svc/mostpopular/v2/viewed/30.json?api-key=DlQRz2ja95vcwPkcWyen4da4dHLGeP7k")
    
    func getMostPopularArticles(completion: @escaping (Result<NewYorkTimesResponseModel, Error>) -> Void) {
        guard let url = newYorkTimesURL else { return }
        
        let task = URLSession.shared.dataTask(with: url) { data, _, error in
            if let error = error {
                completion(.failure(error))
            }
            else if let data = data {
                do {
                    let result = try JSONDecoder().decode(NewYorkTimesResponseModel.self, from: data)
                    completion(.success(result))
                } catch {
                    completion(.failure(error))
                }
            }
        }
        task.resume()
    }
    
    func getImage(imageURL: URL, completion: @escaping (UIImage?, Error?) -> Void) {
        
        let task = URLSession.shared.dataTask(with: imageURL) { data, _, error in
            if !(data?.isEmpty ?? false) {
                completion(UIImage(data: data!), error)
            }
        }
        task.resume()
    }
}
