//
//  UITableView.swift
//  NYNewsArticlesAPI
//
//  Created by Luke Barkhuizen (ZA) on 2023/09/20.
//

import UIKit

public extension UITableView {
    
    func registerNib(named name: String, bundle: Bundle = .main) {
        self.register(UINib(nibName: name, bundle: bundle), forCellReuseIdentifier: name)
    }
}
