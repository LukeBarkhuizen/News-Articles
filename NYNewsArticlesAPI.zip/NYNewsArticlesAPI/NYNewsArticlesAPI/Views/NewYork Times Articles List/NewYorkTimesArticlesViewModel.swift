//
//  NewYorkTimesArticlesViewModel.swift
//  NYNewsArticlesAPI
//
//  Created by Luke Barkhuizen (ZA) on 2023/09/20.
//

import UIKit

protocol NewYorkTimesArticlesViewModelDelegate {
    
    func configureArticleList(articles: [TopArticles])
}

class NewYorkTimesArticlesViewModel {
    
    var delegate: NewYorkTimesArticlesViewModelDelegate?
    
    init(delegate: NewYorkTimesArticlesViewModelDelegate) {
        self.delegate = delegate
    }
    
    func getAllMostPopularArticles() {
        APICaller.shared.getMostPopularArticles { result in
            switch result {
            case .success(let response):
                let articles = response.results ?? [TopArticles]()
                self.delegate?.configureArticleList(articles: articles)
            case .failure(let error):
                print(error)
            }
        }
    }
}
