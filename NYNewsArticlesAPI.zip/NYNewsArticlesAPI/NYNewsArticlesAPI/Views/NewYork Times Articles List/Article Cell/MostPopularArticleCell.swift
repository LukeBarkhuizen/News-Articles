//
//
//  MostPopularArticleCell.swift
//  NY_MostPopularArticle
//
//  Created by Luke Barkhuizen (ZA) on 2023/09/19.
//

import UIKit

final class MostPopularArticleCell: UITableViewCell {
    
    @IBOutlet var articleImage: UIImageView!
    @IBOutlet var titleLabelView: UILabel!
    @IBOutlet var authorLabelView: UILabel!
    @IBOutlet var publishedDateLabelView: UILabel!
    
    override func layoutSubviews() {
        super.layoutSubviews()
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        articleImage.clipsToBounds = true;
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
    func configureCellView(articleModel: TopArticles) {
        articleImage.image = UIImage(systemName: "photo")
        titleLabelView.text = articleModel.articleTitle ?? "-"
        authorLabelView.text = articleModel.author ?? "-"
        publishedDateLabelView.text = "Date published: \(articleModel.publishedDate ?? "-")"
        
        // Set Article Image
        let image = articleModel.articleImage?.first?.image?.first?.imageURL ?? ""
        guard !image.isEmpty else { return }
        let firstArticleImageURL = URL(string: image)!
        APICaller.shared.getImage(imageURL: firstArticleImageURL) { (image, error) in
            DispatchQueue.main.async() { () -> Void in
                self.articleImage?.image = image
            }
        }
        
    }
}

