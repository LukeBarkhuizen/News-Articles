//
//  NewYorkTimesArticlesViewController.swift
//  NYNewsArticlesAPI
//
//  Created by Luke Barkhuizen (ZA) on 2023/09/19.
//

import UIKit

final class NewYorkTimesArticlesViewController: UIViewController {
    
    @IBOutlet private var tableView: UITableView!
    
    private var datasource: [TopArticles] = []
    var selectedArticle: TopArticles?
    
    var articles: [TopArticles] = [] {
        didSet {
            DispatchQueue.main.async {
                self.tableView.reloadData()
            }
        }
    }
    
    lazy var viewModel = NewYorkTimesArticlesViewModel(delegate: self)
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableViewSettings()
        viewModel.getAllMostPopularArticles()
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
    if segue.identifier == "NewYorkTimesArticleDetailsSegue" {
        let articleDetailsViewController = segue.destination as! NewYorkTimesArticleDetailsViewController
        articleDetailsViewController.articleDetails = selectedArticle
    }
}
    
    func tableViewSettings() {
        tableView.rowHeight = UITableView.automaticDimension
        tableView.backgroundColor = UIColor.clear
        tableView.rowHeight = UITableView.automaticDimension
        tableView.estimatedRowHeight = 100
        tableView.dataSource = self
        tableView.delegate = self
        tableView.registerNib(named: "MostPopularArticleCell")
    }
}


// MARK: - NewYorkTimesArticlesViewModelDelegate

extension NewYorkTimesArticlesViewController: NewYorkTimesArticlesViewModelDelegate {
    
    func configureArticleList(articles: [TopArticles]) {
        self.articles = articles
    }
}

// MARK: - UITableViewDataSource & UITableViewDelegate

extension NewYorkTimesArticlesViewController: UITableViewDataSource, UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell: MostPopularArticleCell = tableView.dequeueReusableCell(withIdentifier: "MostPopularArticleCell", for: indexPath) as! MostPopularArticleCell
        cell.configureCellView(articleModel: articles[indexPath.item])
        return cell
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.articles.count
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        selectedArticle = self.articles[indexPath.item]
        performSegue(withIdentifier: "NewYorkTimesArticleDetailsSegue", sender: nil)
        self.tableView.deselectRow(at: indexPath, animated: true)
    }
}

