//
//  NewYorkTimesArticleDetailsViewController.swift
//  NYNewsArticlesAPI
//
//  Created by Luke Barkhuizen (ZA) on 2023/09/20.
//

import UIKit

final class NewYorkTimesArticleDetailsViewController: UIViewController {
    
    @IBOutlet private var articleContentLabel: UILabel!
    @IBOutlet private var sectionLabel: UILabel!
    @IBOutlet private var titleLabel: UILabel!
    @IBOutlet private var authorLabel: UILabel!
    @IBOutlet private var publishedDateLabel: UILabel!
    @IBOutlet private var articleImageView: UIImageView!
    
    var articleDetails: TopArticles?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        configureArticleDetails()
    }
    
    func configureArticleDetails() {
        if let article = articleDetails {
            articleContentLabel.text = article.articleContent ?? "-"
            sectionLabel.text = "Article section: \(article.articleSection ?? "-")"
            titleLabel.text = article.articleTitle ?? "-"
            authorLabel.text = article.author ?? "-"
            publishedDateLabel.text = "Published date: \(article.publishedDate ?? "-")"

            // Set Article Image
            let image = articleDetails?.articleImage?.first?.image?.first?.imageURL ?? ""
            guard !image.isEmpty else { return }
            let firstArticleImageURL = URL(string: image)!
            APICaller.shared.getImage(imageURL: firstArticleImageURL) { (image, error) in
                DispatchQueue.main.async() { () -> Void in
                    self.articleImageView?.image = image
                }
            }
        }
    }
}
