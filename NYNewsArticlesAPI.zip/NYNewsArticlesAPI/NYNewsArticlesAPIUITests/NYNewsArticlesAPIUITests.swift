//
//  NYNewsArticlesAPIUITests.swift
//  NYNewsArticlesAPIUITests
//
//  Created by Luke Barkhuizen (ZA) on 2023/09/19.
//

import XCTest

class NYNewsArticlesAPIUITests: XCTestCase {
    
    override func setUp() {
        super.setUp()
        continueAfterFailure = false
        XCUIApplication().launch()
    }
    
    override func tearDown() {
        super.tearDown()
    }
    
    func testTableViewInteraction() {
        let app = XCUIApplication()
        let tableView = app.tables["Empty list"]
        
        // Check if the table view exists
        XCTAssertTrue(tableView.exists)
        
        // Verify the number of cells in the table view
        let cellCount = tableView.cells.count
        XCTAssertEqual(cellCount, 0)
    
        tableView.swipeUp()
        tableView.swipeDown()
    }
}
